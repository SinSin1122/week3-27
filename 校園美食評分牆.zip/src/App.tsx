/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import { 
  collection, 
  addDoc, 
  onSnapshot, 
  query, 
  orderBy, 
  updateDoc, 
  doc, 
  increment,
  serverTimestamp,
  Timestamp
} from 'firebase/firestore';
import { 
  signInWithPopup, 
  GoogleAuthProvider, 
  onAuthStateChanged, 
  User,
  signOut
} from 'firebase/auth';
import { db, auth, OperationType, handleFirestoreError } from './firebase';
import { Review, Category, RestaurantStats } from './types';
import { StarRating } from './components/StarRating';
import { ErrorBoundary } from './components/ErrorBoundary';
import { cn } from '@/lib/utils';

// UI Components
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';
import { 
  Plus, 
  ThumbsUp, 
  Trophy, 
  MessageSquare, 
  Filter, 
  LogOut, 
  LogIn,
  UtensilsCrossed,
  Clock,
  CheckCircle,
  Circle
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { formatDistanceToNow } from 'date-fns';
import { zhTW } from 'date-fns/locale';

export default function App() {
  return (
    <ErrorBoundary>
      <CampusFoodWall />
    </ErrorBoundary>
  );
}

function CampusFoodWall() {
  const [user, setUser] = useState<User | null>(null);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [filterStatus, setFilterStatus] = useState<'all' | 'active' | 'done'>('all');
  const [loading, setLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Form State
  const [restaurantName, setRestaurantName] = useState('');
  const [category, setCategory] = useState<Category>('一飯');
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState('');

  // Auth Listener
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  // Firestore Listener
  useEffect(() => {
    const q = query(collection(db, 'reviews'), orderBy('createdAt', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const reviewsData = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Review[];
      
      // Client-side sorting: active first, then done, then by date desc
      const sortedReviews = [...reviewsData].sort((a, b) => {
        const aStatus = a.status || 'active';
        const bStatus = b.status || 'active';
        
        if (aStatus === bStatus) {
          const aTime = a.createdAt?.toMillis?.() || 0;
          const bTime = b.createdAt?.toMillis?.() || 0;
          return bTime - aTime;
        }
        
        return aStatus === 'active' ? -1 : 1;
      });

      setReviews(sortedReviews);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'reviews');
    });

    return () => unsubscribe();
  }, []);

  // Rankings Logic
  const rankings = useMemo(() => {
    const statsMap = new Map<string, { totalRating: number; count: number; category: Category }>();
    
    reviews.forEach(review => {
      const current = statsMap.get(review.restaurantName) || { totalRating: 0, count: 0, category: review.category };
      statsMap.set(review.restaurantName, {
        totalRating: current.totalRating + review.rating,
        count: current.count + 1,
        category: review.category
      });
    });

    return Array.from(statsMap.entries())
      .map(([name, stats]) => ({
        name,
        averageRating: Number((stats.totalRating / stats.count).toFixed(1)),
        reviewCount: stats.count,
        category: stats.category
      }))
      .sort((a, b) => b.averageRating - a.averageRating || b.reviewCount - a.reviewCount)
      .slice(0, 5);
  }, [reviews]);

  const filteredReviews = useMemo(() => {
    if (filterStatus === 'all') return reviews;
    return reviews.filter(review => {
      const status = review.status || 'active';
      return status === filterStatus;
    });
  }, [reviews, filterStatus]);

  const handleLogin = async () => {
    try {
      const provider = new GoogleAuthProvider();
      await signInWithPopup(auth, provider);
    } catch (error) {
      console.error('Login failed:', error);
    }
  };

  const handleLogout = () => signOut(auth);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    if (!restaurantName || !comment) return;

    setIsSubmitting(true);
    try {
      await addDoc(collection(db, 'reviews'), {
        restaurantName,
        category,
        rating,
        comment,
        likes: 0,
        status: 'active',
        createdAt: serverTimestamp(),
        authorEmail: user.email
      });
      
      // Reset Form
      setRestaurantName('');
      setComment('');
      setRating(5);
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'reviews');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleLike = async (reviewId: string) => {
    if (!user) {
      handleLogin();
      return;
    }
    try {
      const reviewRef = doc(db, 'reviews', reviewId);
      await updateDoc(reviewRef, {
        likes: increment(1)
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `reviews/${reviewId}`);
    }
  };

  const handleToggleStatus = async (reviewId: string, currentStatus: string = 'active') => {
    if (!user) {
      handleLogin();
      return;
    }
    try {
      const reviewRef = doc(db, 'reviews', reviewId);
      await updateDoc(reviewRef, {
        status: currentStatus === 'done' ? 'active' : 'done'
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `reviews/${reviewId}`);
    }
  };

  const formatTime = (createdAt: any) => {
    if (!createdAt) return '剛剛';
    const date = createdAt instanceof Timestamp ? createdAt.toDate() : new Date(createdAt);
    return formatDistanceToNow(date, { addSuffix: true, locale: zhTW });
  };

  return (
    <div className="min-h-screen bg-[#0A0A0B] text-[#F4F4F5] font-sans selection:bg-[#FF5C00] selection:text-white">
      {/* Header */}
      <header className="border-b border-[#27272A] px-10 py-6 flex items-center justify-between sticky top-0 z-50 bg-[#0A0A0B]/90 backdrop-blur-sm">
        <div className="logo text-2xl font-extrabold tracking-tighter uppercase">
          CAMPUS<span className="text-[#FF5C00]">BITES</span>
        </div>

        <div className="leaderboard hidden lg:flex gap-5">
          {rankings.map((res, idx) => (
            <div key={res.name} className="leaderboard-item bg-[#161618] border border-[#27272A] rounded-lg px-4 py-2 flex items-center gap-3">
              <div className="artistic-rank">0{idx + 1}</div>
              <div className="leaderboard-info">
                <span className="block text-[10px] text-[#A1A1AA] uppercase font-semibold tracking-wider">
                  {res.category} • {res.name}
                </span>
                <strong className="text-sm font-bold">{res.averageRating} ★</strong>
              </div>
            </div>
          ))}
        </div>

        <div className="flex items-center gap-4">
          {user ? (
            <Button variant="ghost" size="sm" onClick={handleLogout} className="text-[#A1A1AA] hover:text-[#F4F4F5] hover:bg-[#161618]">
              <LogOut className="w-4 h-4 mr-2" />
              登出
            </Button>
          ) : (
            <Button onClick={handleLogin} size="sm" className="bg-[#FF5C00] text-white hover:brightness-110 font-bold">
              <LogIn className="w-4 h-4 mr-2" />
              登入
            </Button>
          )}
        </div>
      </header>

      <main className="grid grid-cols-1 lg:grid-cols-[320px_1fr] min-h-[calc(100vh-80px)]">
        {/* Sidebar */}
        <aside className="sidebar p-10 border-r border-[#27272A] flex flex-col gap-8 bg-[#0A0A0B]">
          <div className="space-y-2">
            <h2 className="text-xl font-bold">發表食評</h2>
            <p className="text-[#A1A1AA] text-xs uppercase tracking-widest">分享你的校園美食體驗</p>
          </div>

          {!user ? (
            <div className="text-center py-10 space-y-4 bg-[#161618] rounded-xl border border-[#27272A]">
              <p className="text-[#A1A1AA] text-xs uppercase">請先登入</p>
              <Button onClick={handleLogin} variant="outline" className="border-[#27272A] hover:bg-[#27272A] text-white">
                Google 登入
              </Button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="flex flex-col gap-6">
              <div className="flex flex-col gap-2">
                <label className="text-[10px] text-[#A1A1AA] uppercase tracking-widest font-bold">餐廳名稱</label>
                <input 
                  type="text" 
                  placeholder="輸入店名..."
                  value={restaurantName}
                  onChange={(e) => setRestaurantName(e.target.value)}
                  className="artistic-input"
                  required
                />
              </div>

              <div className="flex flex-col gap-2">
                <label className="text-[10px] text-[#A1A1AA] uppercase tracking-widest font-bold">分類</label>
                <select 
                  value={category} 
                  onChange={(e) => setCategory(e.target.value as Category)}
                  className="artistic-input appearance-none"
                >
                  <option value="一飯">一飯</option>
                  <option value="二飯">二飯</option>
                  <option value="校外">校外</option>
                </select>
              </div>

              <div className="flex flex-col gap-2">
                <label className="text-[10px] text-[#A1A1AA] uppercase tracking-widest font-bold">評分</label>
                <StarRating rating={rating} onRatingChange={setRating} size={20} />
              </div>

              <div className="flex flex-col gap-2">
                <label className="text-[10px] text-[#A1A1AA] uppercase tracking-widest font-bold">評論</label>
                <textarea 
                  rows={4} 
                  placeholder="味道如何？有無雷點？"
                  value={comment}
                  onChange={(e) => setComment(e.target.value)}
                  className="artistic-input min-h-[120px]"
                  required
                />
              </div>

              <button type="submit" disabled={isSubmitting} className="artistic-btn-primary mt-2">
                {isSubmitting ? "提交中..." : "提交評分"}
              </button>
            </form>
          )}
        </aside>

        {/* Wall */}
        <section className="wall p-8 overflow-y-auto">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
            <div className="flex items-center gap-2">
              <MessageSquare className="text-zinc-400 w-5 h-5" />
              <h2 className="text-xl font-bold uppercase tracking-tight">最新食評</h2>
              <Badge variant="outline" className="border-[#27272A] text-zinc-500 text-[10px]">
                {filteredReviews.length}
              </Badge>
            </div>
            
            <div className="flex items-center gap-1 bg-[#161618] p-1 rounded-lg border border-[#27272A]">
              <button 
                onClick={() => setFilterStatus('all')}
                className={cn(
                  "px-3 py-1 rounded-md text-[10px] font-bold uppercase tracking-wider transition-all",
                  filterStatus === 'all' 
                    ? "bg-[#FF5C00] text-white" 
                    : "text-zinc-500 hover:text-zinc-300 hover:bg-zinc-800/50"
                )}
              >
                全部
              </button>
              <button 
                onClick={() => setFilterStatus('active')}
                className={cn(
                  "px-3 py-1 rounded-md text-[10px] font-bold uppercase tracking-wider transition-all",
                  filterStatus === 'active' 
                    ? "bg-[#FF5C00] text-white" 
                    : "text-zinc-500 hover:text-zinc-300 hover:bg-zinc-800/50"
                )}
              >
                正在進行
              </button>
              <button 
                onClick={() => setFilterStatus('done')}
                className={cn(
                  "px-3 py-1 rounded-md text-[10px] font-bold uppercase tracking-wider transition-all",
                  filterStatus === 'done' 
                    ? "bg-[#FF5C00] text-white" 
                    : "text-zinc-500 hover:text-zinc-300 hover:bg-zinc-800/50"
                )}
              >
                已完成
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 content-start">
            <AnimatePresence mode="popLayout">
              {filteredReviews.map((review) => (
                <motion.div
                  key={review.id}
                  layout
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  transition={{ duration: 0.3 }}
                  className={cn(
                    "artistic-card group transition-all duration-500",
                    review.status === "done" && "opacity-50 grayscale-[0.2]"
                  )}
                >
                  <div className="flex justify-between items-start mb-3">
                    <div className="flex items-center gap-2">
                      <div className="artistic-tag">{review.category}</div>
                      {review.status === "done" && (
                        <Badge variant="outline" className="text-[10px] border-zinc-700 text-zinc-500 uppercase font-bold px-1.5 py-0">
                          DONE
                        </Badge>
                      )}
                    </div>
                    <div className="text-[11px] text-[#A1A1AA] flex items-center gap-1">
                      <Clock size={10} />
                      {formatTime(review.createdAt)}
                    </div>
                  </div>

                  <h3 className={cn(
                    "text-lg font-bold mb-1",
                    review.status === "done" && "line-through text-zinc-500"
                  )}>
                    {review.restaurantName}
                  </h3>
                  <div className="mb-3">
                    <StarRating rating={review.rating} readonly size={14} />
                  </div>

                  <p className={cn(
                    "text-sm leading-relaxed text-[#A1A1AA] mb-5 line-clamp-4 group-hover:line-clamp-none transition-all",
                    review.status === "done" && "line-through opacity-60"
                  )}>
                    {review.comment}
                  </p>

                  <div className="flex justify-between items-center pt-4 border-t border-[#272728]">
                    <div className="flex items-center gap-2">
                       <button 
                        onClick={() => handleToggleStatus(review.id, review.status)}
                        className={cn(
                          "flex items-center gap-1.5 px-2 py-1 rounded-md text-[10px] font-bold uppercase tracking-wider transition-all",
                          review.status === "done" 
                            ? "bg-zinc-800 text-zinc-400 hover:bg-zinc-700" 
                            : "bg-zinc-900 border border-zinc-800 text-zinc-500 hover:border-accent/40 hover:text-zinc-300"
                        )}
                        title={review.status === "done" ? "標記為未完成" : "標記為已打卡"}
                      >
                        {review.status === "done" ? <CheckCircle size={12} className="text-agree" /> : <Circle size={12} />}
                        {review.status === "done" ? "已打卡" : "打卡"}
                      </button>
                      <div className="text-[10px] text-[#A1A1AA] italic font-medium">
                        {review.authorEmail ? `${review.authorEmail.split('@')[0]}` : '匿名'}
                      </div>
                    </div>
                    <button 
                      onClick={() => handleLike(review.id)}
                      className="artistic-btn-agree"
                    >
                      <span className="text-sm font-bold">+</span> 1 認同 ({review.likes})
                    </button>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>

            {reviews.length === 0 && !loading && (
              <div className="col-span-full text-center py-32 space-y-4 bg-[#161618]/50 rounded-2xl border border-dashed border-[#27272A]">
                <MessageSquare className="mx-auto text-[#27272A]" size={48} />
                <p className="text-[#A1A1AA] text-sm uppercase tracking-widest">目前還沒有食評</p>
              </div>
            )}
          </div>
        </section>
      </main>
    </div>
  );
}
