export type Category = '一飯' | '二飯' | '校外';

export interface Review {
  id: string;
  restaurantName: string;
  category: Category;
  rating: number;
  comment: string;
  likes: number;
  status?: 'active' | 'done';
  createdAt: any; // Firestore Timestamp
  authorEmail?: string;
}

export interface RestaurantStats {
  name: string;
  averageRating: number;
  reviewCount: number;
  category: Category;
}
